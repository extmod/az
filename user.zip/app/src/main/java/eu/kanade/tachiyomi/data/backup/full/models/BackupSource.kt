package eu.kanade.tachiyomi.data.backup.full.models

import eu.kanade.tachiyomi.source.Source
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.Serializable
import kotlinx.serialization.protobuf.ProtoNumber

@ExperimentalSerializationApi
@Serializable
data class BackupSource(
    @ProtoNumber(1) var name: String = "",
    @ProtoNumber(2) var sourceId: Long
) {
    companion object {
        fun copyFrom(source: Source): BackupSource {
            return BackupSource(
                name = source.name,
                sourceId = source.id
            )
        }
    }
}

@Serializable
data class BrokenBackupSource(
    @ProtoNumber(0) var name: String = "",
    @ProtoNumber(1) var sourceId: Long
) {
    fun toBackupSource() = BackupSource(name, sourceId)
}
