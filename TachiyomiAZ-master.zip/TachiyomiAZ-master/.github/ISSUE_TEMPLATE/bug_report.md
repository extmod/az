---
name: "🐞 Bug report"
about: Report a bug
title: "[Bug] Write short description here"
labels: "bug"
---

**PLEASE READ THIS**

I acknowledge that:

- I have updated to the latest version of the app (stable is v8.7.0)
- I have updated all extensions
- If this is an issue with an extension, that I should be opening an issue in https://github.com/inorichi/tachiyomi-extensions

**DELETE THIS SECTION IF YOU HAVE READ AND ACKNOWLEDGED IT**

---

### Device information
* Tachiyomi version: ?
* Android version: ?
* Device: ?

## Steps to reproduce
1. First step
2. Second step

### Expected behavior
This should happen.

### Actual behavior
This happened instead.

### Other details
Additional details and attachments.
